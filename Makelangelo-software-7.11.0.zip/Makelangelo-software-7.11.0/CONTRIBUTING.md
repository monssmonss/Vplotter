See: [Makelangelo's wiki entry for developers](https://github.com/MarginallyClever/Makelangelo/wiki#developers).

Quick Installation

```sh
git clone https://github.com/MarginallyClever/Makelangelo.git ~/Makelangelo
cd ~/Makelangelo
script/bootstrap
```
