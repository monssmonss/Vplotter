package com.marginallyclever.voronoi;

public class VoronoiCellEdge {
  public double px, py;
  public double nx, ny;
}
