package com.marginallyclever.communications;

import javax.swing.JPanel;

public class TransportLayerPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8909954928628121764L;

	public NetworkConnection openConnection() {
		return null;
	}
}
