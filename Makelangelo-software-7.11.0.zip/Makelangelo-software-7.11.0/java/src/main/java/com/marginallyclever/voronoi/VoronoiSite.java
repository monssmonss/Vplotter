package com.marginallyclever.voronoi;

import java.awt.Point;

public class VoronoiSite {
  public Point coord;
  public int sitenbr;

  public VoronoiSite() {
    coord = new Point();
  }
}
