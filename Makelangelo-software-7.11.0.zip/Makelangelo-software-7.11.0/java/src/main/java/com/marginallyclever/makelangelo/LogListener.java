package com.marginallyclever.makelangelo;

public interface LogListener {
	// decorated HTML message has been logged
	public void logEvent(String message);
}
