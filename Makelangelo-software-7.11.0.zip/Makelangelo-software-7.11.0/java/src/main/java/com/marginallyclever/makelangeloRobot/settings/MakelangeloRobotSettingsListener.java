package com.marginallyclever.makelangeloRobot.settings;

public interface MakelangeloRobotSettingsListener {
	public void settingsChangedEvent(MakelangeloRobotSettings settings);
}
